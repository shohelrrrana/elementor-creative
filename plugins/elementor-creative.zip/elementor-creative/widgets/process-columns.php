<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Process_Columns extends Widget_Base {

    public function get_name () {
        return 'process_columns';
    }

    public function get_title () {
        return __( 'Process Columns', 'elementor-creative' );
    }

    public function get_icon () {
        return 'fa fa-spinner';
    }

    public function get_categories () {
        return [ 'general', 'custom' ];
    }

    protected function _register_controls () {
        $this->register_content_controls();

    }

    protected function register_content_controls () {
        $this->start_controls_section( 'section_content', [
                'label' => __( 'Content', 'elementor-creative' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control( 'bg_color', [
                'label'     => __( 'Background Color', 'elementor-creative' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#26313c',
                'selectors' => [ '{{WRAPPER}} .process-wrapp' => 'background: {{VALUE}}' ],
            ]
        );

        $this->add_control( 'text_color', [
                'label'     => __( 'Text Color', 'elementor-creative' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#26313c',
                'selectors' => [
                    '{{WRAPPER}} p'                         => 'color: {{VALUE}}',
                    '{{WRAPPER}} span'                      => 'color: {{VALUE}}',
                    '{{WRAPPER}} .pro-step '                => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .process-wrapp li::before' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .process-wrapp li::after'  => 'background: {{VALUE}}',
                ],
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control( 'process_title', [
            'label' => __( 'Process Title', 'elementor-creative' ),
            'type'  => Controls_Manager::TEXT,
        ] );

        $repeater->add_control( 'title', [
            'label' => __( 'Title', 'elementor-creative' ),
            'type'  => Controls_Manager::TEXT,
        ] );

        $repeater->add_control( 'title', [
            'label' => __( 'Title', 'elementor-creative' ),
            'type'  => Controls_Manager::TEXT,
        ] );

        $repeater->add_control( 'description', [
            'label' => __( 'Description', 'elementor-creative' ),
            'type'  => Controls_Manager::TEXTAREA,
        ] );

        $this->add_control( 'process_list', [
                'label'       => __( 'Process Columns', 'elementor-creative' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{title}}',
            ]
        );

        $this->end_controls_section();
    }


    protected function render () {
        $process_list = $this->get_settings( 'process_list' );
        if ( ! empty( $process_list ) ):
            ?>
            <ul class="process-wrapp">

                <?php foreach ( $process_list as $process ): ?>
                    <li class="whitecolor wow fadeIn" data-wow-delay="300ms"
                        style="visibility: visible; animation-delay: 300ms; animation-name: fadeIn;">
                        <span class="pro-step bottom20">
                            <?php echo esc_html( $process['process_title'] ); ?>
                        </span>
                        <p class="fontbold bottom25">
                            <?php echo esc_html( $process['title'] ); ?>
                        </p>
                        <p class="mt-n2 mt-sm-0">
                            <?php echo esc_html( $process['description'] ); ?>
                        </p>
                    </li>
                <?php endforeach; ?>

            </ul>
        <?php
        endif;
    }

    public function _content_template () {
        ?>
        <# if(settings.process_list.length){ #>
        <ul class="process-wrapp">
            <# settings.process_list.map(function (process){ #>
            <li class="whitecolor wow fadeIn" data-wow-delay="300ms"
                style="visibility: visible; animation-delay: 300ms; animation-name: fadeIn;">
                        <span class="pro-step bottom20">
                            {{{process.process_title}}}
                        </span>
                <p class="fontbold bottom25">
                    {{{process.title}}}
                </p>
                <p class="mt-n2 mt-sm-0">
                    {{{process.description}}}
                </p>
            </li>
            <# }) #>
        </ul>
        <# } #>
        <?php
    }
}
