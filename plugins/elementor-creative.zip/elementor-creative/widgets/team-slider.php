<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Team_Slider extends Widget_Base {

    public function get_name () {
        return 'team_slider';
    }

    public function get_title () {
        return __( 'Team Slider', 'elementor-creative' );
    }

    public function get_icon () {
        return 'fa fa-user-friends';
    }

    public function get_categories () {
        return [ 'general', 'custom' ];
    }

    protected function _register_controls () {
        $this->register_content_controls();

    }

    protected function register_content_controls () {
        $this->start_controls_section( 'section_content', [
                'label' => __( 'Content', 'elementor-creative' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control( 'image', [
            'label' => __( 'Image', 'elementor-creative' ),
            'type'  => Controls_Manager::MEDIA,
        ] );

        $repeater->add_control( 'name', [
            'label' => __( 'Name', 'elementor-creative' ),
            'type'  => Controls_Manager::TEXT,
        ] );

        $repeater->add_control( 'title', [
            'label' => __( 'Title', 'elementor-creative' ),
            'type'  => Controls_Manager::TEXT,
        ] );

        $repeater->add_control( 'facebook_link', [
            'label' => __( 'Facebook Link', 'elementor-creative' ),
            'type'  => Controls_Manager::TEXT,
        ] );

        $repeater->add_control( 'twitter_link', [
            'label' => __( 'Twitter Link', 'elementor-creative' ),
            'type'  => Controls_Manager::TEXT,
        ] );

        $repeater->add_control( 'instagram_link', [
            'label' => __( 'Instagram Link', 'elementor-creative' ),
            'type'  => Controls_Manager::TEXT,
        ] );

        $this->add_control( 'show_columns', [
                'label'   => __( 'Show Columns', 'elementor-creative' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 4,
                'options' => [
                    2 => __( 'Two', 'elementor-creative' ),
                    3 => __( 'Three', 'elementor-creative' ),
                    4 => __( 'Four', 'elementor-creative' ),
                    5 => __( 'Five', 'elementor-creative' ),
                ],
            ]
        );

        $this->add_control( 'team_list', [
                'label'       => __( 'Process Columns', 'elementor-creative' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{name}}',
            ]
        );

        $this->end_controls_section();
    }


    protected function render () {
        $team_list = $this->get_settings( 'team_list' );
        $show_columns = $this->get_settings( 'show_columns' );
        if ( ! empty( $team_list ) ):
            ?>
            <div id="ourteam-slider" class="ourteam-slider owl-carousel"
                 data-show_columns="<?php echo esc_attr( $show_columns ); ?>">

                <?php foreach ( $team_list as $item ) : ?>
                    <div class="item">
                        <div class="team-box">
                            <div class="image">
                                <img src="<?php echo esc_url( $item['image']['url'] ); ?>"
                                     alt="<?php echo esc_attr( $item['name'] ); ?>">
                            </div>
                            <div class="team-content">
                                <h4 class="darkcolor">
                                    <?php echo esc_html( $item['name'] ); ?>
                                </h4>
                                <p>
                                    <?php echo esc_html( $item['title'] ); ?>
                                </p>
                                <ul class="social-icons-simple">
                                    <?php if ( $item['facebook_link'] ): ?>
                                        <li>
                                            <a class="facebook" href="<?php echo esc_url( $item['facebook_link'] ); ?>">
                                                <i class="fa fa-facebook-f"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if ( $item['twitter_link'] ): ?>
                                        <li>
                                            <a class="twitter" href="<?php echo esc_url( $item['twitter_link'] ); ?>">
                                                <i class="fa fa-twitter"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if ( $item['instagram_link'] ): ?>
                                        <li>
                                            <a class="insta" href="<?php echo esc_url( $item['instagram_link'] ); ?>">
                                                <i class="fa fa-instagram"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>

            </div>
        <?php
        endif;
    }

    public function _content_template () {
        ?>
        <# if(settings.team_list.length){ #>
        <div id="ourteam-slider" class="ourteam-slider owl-carousel" data-show_columns="{{{settings.show_columns}}}">
            <# settings.team_list.map(function (item){ #>
            <div class="item">
                <div class="team-box">
                    <div class="image">
                        <img src="{{{item.image.url}}}"
                             alt="{{{item.name}}}">
                    </div>
                    <div class="team-content">
                        <h4 class="darkcolor">
                            {{{item.name}}}
                        </h4>
                        <p>
                            {{{item.title}}}
                        </p>
                        <ul class="social-icons-simple">
                            <# if ( item.facebook_link ){ #>
                            <li>
                                <a class="facebook" href="{{{item.facebook_link}}}">
                                    <i class="fa fa-facebook-f"></i>
                                </a>
                            </li>
                            <# } #>
                            <# if ( item.twitter_link ){ #>
                            <li>
                                <a class="twitter" href="{{{item.twitter_link}}}">
                                    <i class="fa fa-twitter"></i>
                                </a>
                            </li>
                            <# } #>
                            <# if ( item.instagram_link ){ #>
                            <li>
                                <a class="insta" href="{{{item.instagram_link}}}">
                                    <i class="fa fa-instagram"></i>
                                </a>
                            </li>
                            <# } #>
                        </ul>
                    </div>
                </div>
            </div>
            <# }) #>
        </div>
        <# } #>
        <?php
    }


}
