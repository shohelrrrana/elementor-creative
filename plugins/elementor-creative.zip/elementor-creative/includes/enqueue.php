<?php

class EL_Enqueue {

    public function __construct () {
        add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'enqueue_frontend_styles' ] );
        add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'enqueue_frontend_scripts' ] );
    }

    public function enqueue_frontend_styles () {
        wp_enqueue_style( 'owl-carousel-min-css', plugins_url('/../assets/css/owl.carousel.min.css', __FILE__), [], time() );
        wp_enqueue_style( 'style-css', plugins_url('/../assets/css/style.css', __FILE__), [], time() );
    }

    public function enqueue_frontend_scripts () {
        wp_enqueue_script( 'owl-carousel-min-js', plugins_url( '/../assets/js/owl.carousel.min.js', __FILE__ ), [], time(), true );
        wp_enqueue_script( 'scripts-js', plugins_url( '/../assets/js/scripts.js', __FILE__ ), [], time(), true );
    }
}