(function ($) {

    // Make sure you run this code under Elementor.
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/team_slider.default', function($scope, $) {
            let show_columns = $scope.find('.ourteam-slider').data('show_columns')
            $(".ourteam-slider").owlCarousel({
                items: show_columns,
                margin: 0,
                dots: false,
                nav: false,
                responsive: {
                    1280: {
                        items: show_columns,
                    },
                    768: {
                        items: 3,
                    },
                    520: {
                        items: 2,
                    },
                    0: {
                        items: 1,
                    },
                }
            });
        });
    });

})(jQuery);
